# Time_Series_Prediction
This is the code for "Time Series Prediction" By Siraj Raval on Youtube

## Overview

This is the code for [this](https://youtu.be/d4Sn6ny_5LI) video on youtube by Siraj Raval on time series prediction. 

## Dependencies

* pandas
* numpy
* matplotlib
* sklearn

Install dependencies via [pip](https://pypi.org/project/pip/) or just run this notebook in the [cloud](https://colab.research.google.com) 

## Usage

Run the jupyter notebook to see all the techniques.

## Credits

Credits for this code goes to [aniruddhpillai16](https://github.com/anirudhpillai16/Time-Series-Analysis/blob/master/Time%20Series%20Analytics%20Vidhya.ipynb). I've merely created a wrapper to get people started. 
